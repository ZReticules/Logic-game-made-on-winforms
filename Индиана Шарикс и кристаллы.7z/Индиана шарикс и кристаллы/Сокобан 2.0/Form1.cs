﻿using System;
using System.Drawing;
using System.IO;
using System.Media;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Сокобан_2._0
{
    public partial class Form1 : Form
    {
        public PictureBox pic2 = new PictureBox();
        public PictureBox[,] pic4 = new PictureBox[100, 100];
        public Label pip = new Label();
        int Lev = 1;
        int to = 0;
        int x = 0;
        TextureBrush prep0;
        TextureBrush prep4;
        TextureBrush prep5;
        TextureBrush prep7;
        bool afte = true;
        int vbok = 7;
        Image[] PlayerModels= new Image[5];

        public Form1()
        {
            InitializeComponent();
            SetStyle(ControlStyles.DoubleBuffer, false);
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            label2.Left = Screen.PrimaryScreen.Bounds.Width - label2.Width-10;
            label4.Left = (Screen.PrimaryScreen.Bounds.Width - label4.Width) /2;
            label5.Left = (Screen.PrimaryScreen.Bounds.Width - label5.Width) / 2;
            label6.Left = (Screen.PrimaryScreen.Bounds.Width - label6.Width) / 2;
            label7.Left = (Screen.PrimaryScreen.Bounds.Width - label7.Width) / 2;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            Image img = Image.FromFile("Lu\\кнопка(светлая).png");
            label1.Image = img;
            label2.Image = img;
            label4.Image = img;
            label5.Image = img;
            label6.Image = img;
            label7.Image = img;
            prep[0] = "Lu\\0.jpg";
            prep[1] = "Lu\\X.png";
            prep[2] = "Lu\\33.jpg";
            prep[3] = "Lu\\J.png";
            prep[4] = "Lu\\pim.jpg";
            prep[5] = "Lu\\1.jpg";
            prep[7] = "Lu\\11.jpg";
            prep[8] = "Lu\\12.jpg";
            prep[9] = "Lu\\16.jpg";
            Image myImage = Image.FromFile("Lu\\0.jpg");
            prep0 = new TextureBrush(myImage);
            myImage = Image.FromFile("Lu\\pim.png");
            prep4 = new TextureBrush(myImage);
            myImage = Image.FromFile("Lu\\1.jpg");
            prep5 = new TextureBrush(myImage);
            myImage = Image.FromFile("Lu\\Q.jpg");
            prep7 = new TextureBrush(myImage);
            PlayerModels[1] = Image.FromFile("Lu\\face.png");
            PlayerModels[2] = Image.FromFile("Lu\\back.png");
            PlayerModels[3] = Image.FromFile("Lu\\right.png");
            PlayerModels[4] = Image.FromFile("Lu\\left.png");
        }
        string[] prep = new string[20];
        private Bitmap paintBitmap;
        private Graphics gr;
        private async void NewMethod()
        {
            if (pic2 != null)
            { Controls.Remove(pic2); }
            await Task.Delay(311);
            x = 0;
            uo = 0;
            to = 1;
            pictureBox1.Top = 60;
            pictureBox1.Left = 0;
            pictureBox1.Load("Zero.png");
            paintBitmap = (Bitmap)pictureBox1.Image;
            gr = Graphics.FromImage(paintBitmap);
            string pio = "Lv\\Уровень " + Convert.ToString(Lev) + ".txt";
            if (dio == 1) pio = duo;
            try
            {
                using (var sr = new StreamReader(pio))
                {
                    string T = sr.ReadToEnd();
                    string[] words = T.Split(new String[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                    label3.Text = Path.GetFileNameWithoutExtension(pio);
                    char[,] arr = new char[words.GetUpperBound(0) + 1, words[1].Length];
                    int f = arr.GetUpperBound(0) + 1;
                    int r = arr.Length / f;
                    NewMethod1();
                    x = 0;
                    Image im;
                    Point poi;
                    for (int i = 0; i < f; i++)
                    {
                        for (int c = 0; c < r; c++)
                        {
                            if (pic4[i, c] != null && pic4[i, c].Parent == this)
                            {
                                Controls.Remove(pic4[i, c]);
                            }
                            arr[i, c] = words[i][c];
                            if (arr[i, c] == 'E')
                            {
                                NewMethod5(i, c, 'E');
                            }
                            if (arr[i, c] == 'X')
                            {
                                gr.FillRectangle(prep0, c * 25, i * 25, 24, 24);
                            }
                            if (arr[i, c] == ' ')
                            {
                                gr.FillRectangle(prep5, c * 25, i * 25, 24, 24);
                            }
                            if (arr[i, c] == '0')
                            {
                                gr.FillRectangle(prep4, c * 25, i * 25, 24, 24);
                            }
                            if (arr[i, c] == 'Q')
                            {
                                gr.FillRectangle(prep7, c * 25, i * 25, 24, 24);
                            }
                            if (arr[i, c] == '.')
                            {
                                x++;
                                im = Image.FromFile(prep[1]);
                                poi = new Point(c * 25, i * 25);
                                gr.FillRectangle(prep5, (25 * c), 25 * i, 25, 25);
                                gr.DrawImage(im, poi);
                                Gravity(i, c, '.');
                            }
                            if (arr[i, c] == '*')
                            {
                                im = Image.FromFile(prep[3]);
                                poi = new Point(c * 25, i * 25);
                                gr.FillRectangle(prep5, (25 * c), 25 * i, 25, 25);
                                gr.DrawImage(im, poi);
                                Gravity(i, c, '*');
                            }
                            if (arr[i, c] == '@')
                            {
                                Bitmap bim = new Bitmap(prep[2]);
                                bim.MakeTransparent();
                                gr.FillRectangle(prep5, c * 25, i * 25, 24, 24);
                                poi = new Point(c * 25, i * 25);
                                gr.DrawImage(PlayerModels[1], poi);
                                g = i;
                                t = c;
                            }
                            rio[i, c] = arr[i, c];
                        }
                    }
                    afte = true;
                    per[2] = g * 25;
                    per[1] = t * 25;
                    mant();
                }
                pictureBox1.Invalidate();
                Обновление_экрана();
            }
            catch (FileNotFoundException)
            {
                NewMethod1(); pictureBox1.Load("Zero1.png"); label2.Enabled = false; label2.Visible = false;
            }
        }
        private async void Обновление_экрана()
        {
            await Task.Delay(25);
            while (afte)
            {
                pictureBox1.Invalidate();
                await Task.Delay(1);
            }
        }
        private async void NewMethod5(int i, int c, char A)
        {
            int f = i;
            int ol = c;
            await Task.Delay(600);
            bool death = false;
            while (afte & !death)
            {
                if (rio[i - 1, c] == '*' || rio[i - 1, c] == '.')
                {
                    gr.FillRectangle(prep5, c * 25, i * 25, 24, 24);
                    Смерть_Вражины(f, ol, i, c);
                    death = true; break;
                }
                await Task.Delay(1);
                while (((rio[i, c + 1] == ' ' & rio[i - 1, c] != ' ') || rio[i, c + 1] == '@' || rio[i - 1, c + 1] != ' ') & !death & afte)//вправо
                {
                    if (c == 98 || i == 98) { death = true; break; }
                    if (rio[i - 1, c] == '*' || rio[i - 1, c] == '.')
                    {
                        gr.FillRectangle(prep5, c * 25, i * 25, 24, 24);
                        Смерть_Вражины(f, ol, i, c);
                        death = true; break;
                    }
                    if (rio[i, c + 1] == '@') { Смерть(); afte = false; }
                    int tes = c;
                    if (afte) c = await Движение_врагов(f, ol, i, c, 1, 0, A);
                    if (c == tes) break;
                    if (c == 98 || i == 98) { death = true; break; }
                }
                while ((((rio[i + 1, c] == ' ' & rio[i, c + 1] != ' ') || rio[i + 1, c] == '@') || rio[i + 1, c + 1] != ' ') & !death & afte)//вниз
                {
                    if (c == 98 || i == 98) { death = true; break; }
                    if (rio[i - 1, c] == '*' || rio[i - 1, c] == '.')
                    {
                        gr.FillRectangle(prep5, c * 25, i * 25, 24, 24);
                        Смерть_Вражины(f, ol, i, c);
                        death = true; break;
                    }
                    if (rio[i + 1, c] == '@') { Смерть(); afte = false; }
                    int tes = i;
                    if (afte) i = await Движение_врагов(f, ol, i, c, 0, 1, A);
                    if (i == tes) break;
                    if (c == 98 || i == 98) { death = true; break; }
                }

                while (((rio[i, c - 1] == ' ' & rio[i + 1, c] != ' ') || (rio[i, c - 1] == '@') || rio[i + 1, c - 1] != ' ') & !death & afte)//влево
                {
                    if (c == 98 || i == 98) { death = true; break; }
                    if (rio[i - 1, c] == '*' || rio[i - 1, c] == '.')
                    {
                        gr.FillRectangle(prep5, c * 25, i * 25, 24, 24);
                        Смерть_Вражины(f, ol, i, c);
                        death = true; break;
                    }
                    if (rio[i, c - 1] == '@') { Смерть(); afte = false; }
                    int tes = c;
                    if (afte) c = await Движение_врагов(f, ol, i, c, -1, 0, A);
                    if (c == tes) break;
                    if (c == 98 || i == 98) { death = true; break; }
                }

                while (((rio[i - 1, c] == ' ' & rio[i, c - 1] != ' ') || rio[i - 1, c] == '@' || rio[i - 1, c - 1] != ' ') & !death&afte)//вверх
                {
                    if (c == 98 || i == 98) { death = true; break; }
                    if (rio[i - 1, c] == '*' || rio[i - 1, c] == '.')
                    {
                        gr.FillRectangle(prep5, c * 25, i * 25, 24, 24);
                        Смерть_Вражины(f, ol, i, c);
                        death = true; break;
                    }
                    if (rio[i - 1, c] == '@') { Смерть(); afte = false; }
                    int tes = i;
                    if (afte) i = await Движение_врагов(f, ol, i, c, 0, -1, A);
                    if (i == tes) break;
                    if (i == 98) { death = true; break; }
                }
                if (death) break;
            }
            rio[i, c] = ' ';
        }
        private async Task<int> Движение_врагов(int f, int ol, int I, int c, int go, int opel, char A)
        {
            if (rio[I, c] != 'E')
            {
                gr.FillRectangle(prep5, c * 25, I * 25, 24, 24);
                return 98;
            }
            if (rio[I - 1, c] == '*' || rio[I - 1, c] == '.')
            {
                gr.FillRectangle(prep5, c * 25, I * 25, 24, 24);
                Смерть_Вражины(f, ol, I, c);
                return 98;
            }
            else if (rio[I, c + 1] == '@' || rio[I - 1, c] == '@' || rio[I + 1, c] == '@' || rio[I, c - 1] == '@')
            {
                afte = false;
                Смерть();
            }
            else if (rio[I + 1 * opel, c + 1 * go] == ' ' & afte)
            {
                rio[I, c] = ' ';
                rio[I + 1 * opel, c + 1 * go] = A;
                Image im = Image.FromFile("Lu\\" + Convert.ToString(opel) + Convert.ToString(go) + ".png");
                Point poi = new Point(c * 25 + 25 * go, I * 25 + 25 * opel);
                for (int j = 0; j < 6; j++)
                {
                    poi = new Point(c * 25 + j * 4 * go, I * 25 + j * 4 * opel);
                    if (j > 0) gr.FillRectangle(prep5, 25 * c + j * 4 * go, 25 * I + j * 4 * opel, 25, 25);
                    gr.DrawImage(im, poi);
                    if (rio[I - 1, c] == '*' || rio[I - 1, c] == '.')
                    {
                        rio[I + 1 * opel, c + 1 * go] = ' ';
                        gr.FillRectangle(prep5, 25 * (c + 1 * go), 25 * (I + 1 * opel), 25, 25);
                        Смерть_Вражины(f, ol, I, c);
                        return 98;
                    }
                    await Task.Delay(1);
                    if (j > 0) gr.FillRectangle(prep5, 25 * c + (j - 1) * 4 * go, 25 * I + (j - 1) * 4 * opel, 25, 25);
                }
                poi = new Point(c * 25 + 25 * go, I * 25 + 25 * opel);
                gr.FillRectangle(prep5, 25 * (c + 1 * go), 25 * (I + 1 * opel), 25, 25);
                gr.DrawImage(im, poi);
                c = c + 1 * go;
                I = I + 1 * opel;
            }
            if (opel == 0) return c;
            else return I;
        }

        private async void Gravity(int i, int c, char A)
        {
            int f = i;
            int ol = c;
            await Task.Delay(600);
            bool death = false;
            while (afte & !death)
            {
                if (A == '*')
                {
                    await Task.Delay(25);
                    if (rio[i + 1, c] == ' ')
                    {
                        await Task.Delay(120); 
                        while (((rio[i + 1, c] == ' ' || rio[i + 1, c] == '@')) & rio[i, c] == '*' & afte & !death)//вниз
                        {
                            if (c == 98 || i == 98) { death = true; break; }
                            int tes = i;
                            if (afte) i = await Падение(f, ol, i, c, 0, 1, A);
                            if (c == 98 || i == 98) { death = true; break; }
                            await Task.Delay(2);
                        }
                    }
                    else if (((rio[i, c - 1] == ' ' & rio[i + 1, c - 1] == ' ' & (rio[i + 1, c] == '.' || rio[i + 1, c] == '*') &((rio[i + 2, c - 1] != ' ') || (rio[i + 2, c] != '*' & rio[i + 2, c] != '.' & rio[i + 2, c] != ' '))) || (rio[i, c + 1] == '@' & vbok == 1 & rio[i, c - 1] == ' ' & rio[i, c] == '*')) & !death)//влево
                    {
                        if (afte) c = await Падение(f, ol, i, c, -1, 0, A);
                        c++;
                        if (rio[i, c + 1] == '@' & vbok == 1 & rio[i, c] == ' ')
                        {
                            vbok = 0;
                            rio[g, t] = ' ';
                            rio[g, t-1] = '@';
                            gr.FillRectangle(prep5, per[1], per[2], 24, 24);
                            per[1] = per[1] - 25;
                            Point poi;
                            for (int j = 1; j < 7; j++)
                            {
                                poi = new Point(t * 25 - j * 4, g * 25);
                                gr.FillRectangle(prep5, 25 * t - j * 4, 25 * i, 25, 25);
                                gr.DrawImage(PlayerModels[4], poi);
                                if (per[1] >= Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left + 4;
                                await Task.Delay(1);
                                if (j < 7) gr.FillRectangle(prep5, 25 * t - (j - 1) * 4, 25 * g, 25, 25);
                            }
                            if (per[1] >= Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left + 1;
                            t--;
                            poi = new Point(t * 25, g * 25);
                            gr.DrawImage(PlayerModels[4], poi);
                        }
                        c--;
                        vbok = 10;
                    }
                    else if (((rio[i, c + 1] == ' ' & rio[i + 1, c + 1] == ' ' & (rio[i + 1, c] == '.' || rio[i + 1, c] == '*') &( rio[i + 2, c + 1] != ' ' || (rio[i + 2, c] != '*' & rio[i + 2, c] != '.' & rio[i + 2, c] != ' '))) || (rio[i, c - 1] == '@' & vbok == -1 & rio[i, c + 1] == ' ' & rio[i, c] == '*')) & !death)//вправо
                    {
                        bool ping = false;
                        if (vbok == -1) ping = true;
                        if (afte) c = await Падение(f, ol, i, c, 1, 0, A);
                        c--;
                        if (rio[i, c - 1] == '@' & ping & rio[i, c] == ' ')
                        {
                            vbok = 0;
                            rio[g, t] = ' ';
                            rio[g, t+1] = '@';
                            gr.FillRectangle(prep5, per[1], per[2], 24, 24);
                            per[1] = per[1] + 25;
                            Point poi;
                            for (int j = 1; j < 7; j++)
                            {
                                to = 9;
                                poi = new Point(t * 25 + j * 4, g * 25);
                                gr.FillRectangle(prep5, 25 * t + j * 4, 25 * g, 25, 25);
                                gr.DrawImage(PlayerModels[3], poi);
                                if (per[1] > Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left - 4;
                                await Task.Delay(1);
                                if (j < 7) gr.FillRectangle(prep5, 25 * t + (j - 1) * 4, 25 * g, 25, 25);
                            }
                            if (per[1] > Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left - 1;
                            t++;
                            poi = new Point(t * 25, g * 25);
                            gr.DrawImage(PlayerModels[3], poi);
                            to = 1;
                        }
                        c++;
                        vbok = 10;
                        if (c == 98 || i == 98) { death = true; break; }
                    }
                }
                if (A == '.')
                {
                    await Task.Delay(25);
                    if (rio[i, c] != A) death = true;
                    else if ((rio[i + 1, c] == ' ' & rio[i, c] == '.') & !death)
                    {
                        await Task.Delay(120);
                        while (((rio[i + 1, c] == ' ' || rio[i + 1, c] == '@')) & rio[i, c] == '.' & afte & !death)//вниз
                        {
                            if (c == 98 || i == 98) { death = true; break; }
                            int tes = i;
                            if (afte) i = await Падение(f, ol, i, c, 0, 1, A);
                            if (c == 98 || i == 98) { death = true; break; }
                            await Task.Delay(1);
                        }
                    }
                    else if (((rio[i, c - 1] == ' ' & rio[i + 1, c - 1] == ' ' & (rio[i + 1, c] == '.' || rio[i + 1, c] == '*') & ((rio[i + 2, c - 1] != ' ') || (rio[i + 2, c] != '*' & rio[i + 2, c] != '.' & rio[i + 2, c] != ' ')))) & !death)//влево
                    {
                        if (afte) c = await Падение(f, ol, i, c, -1, 0, A);
                        vbok = 10;
                    }
                    else if (((rio[i, c + 1] == ' ' & rio[i + 1, c + 1] == ' ' & (rio[i + 1, c] == '.' || rio[i + 1, c] == '*') & ((rio[i + 2, c + 1] != ' ') || (rio[i + 2, c] != '*' & rio[i + 2, c] != '.' & rio[i + 2, c] != ' ')))) & !death)//вправо
                    {
                        if (afte) c = await Падение(f, ol, i, c, 1, 0, A);
                        vbok = 10;
                    }
                }
                await Task.Delay(100);
                if (death) break;
            }
        }
        private async Task<int> Падение(int f, int ol, int I, int c, int go, int opel, char A)
        {
            if (rio[I + 1 * opel, c + 1 * go] == ' ' & afte)
            {
                rio[I, c] = ' ';
                rio[I + 1 * opel, c + 1 * go] = A;
                string ugurt = "";
                if (A == '*') ugurt = prep[3];
                else ugurt = "Lu\\X.jpg";
                Image im = Image.FromFile(ugurt);
                TextureBrush eio = new TextureBrush(im);
                Point poi = new Point(c * 25 + 25 * go, I * 25 + 25 * opel);
                for (int j = 1; j < 7; j++)
                {
                    poi = new Point(c * 25 + j * 4 * go, I * 25 + j * 4 * opel);
                    gr.FillRectangle(prep5, 25 * c + j * 4 * go, 25 * I + j * 4 * opel, 25, 25);
                    gr.DrawImage(im, poi);
                    await Task.Delay(1);
                    if (j < 7) gr.FillRectangle(prep5, 25 * c + (j - 1) * 4 * go, 25 * I + (j - 1) * 4 * opel, 25, 25);
                }
                poi = new Point(c * 25 + 25 * go, I * 25 + 25 * opel);
                gr.FillRectangle(prep5, 25 * (c + 1 * go), 25 * (I + 1 * opel), 25, 25);
                gr.DrawImage(im, poi);
                c = c + 1 * go;
                I = I + 1 * opel;
                if (rio[I + 2, c] == '@')
                {
                    afte = false;
                    Смерть();
                }
            }
            if (opel == 0) return c;
            else return I;
        }

        private void NewMethod1()
        {
            for (int i = 0; i < 99; i++)
            {
                for (int c = 0; c < 99; c++)
                {
                    if (pic4[i, c] != null && pic4[i, c].Parent == this)
                    { Controls.Remove(pic4[i, c]); }
                    if (pic2 != null)
                    { Controls.Remove(pic2); }
                    rio[i, c] = '9';
                }
            }
        }
        private async void Смерть()
        {
            pic2 =new PictureBox();
            timer1.Start();
            lion = 0;
            to = 9;
            for(int i=0; i < 100; i++) 
            { for (int c = 0; c < 100; c++) 
                { 
                if(rio[i, c] == '@') 
                    {
                        pic2.Left = 25 * (c - 1)+pictureBox1.Left;
                        pic2.Top = 25 * (i - 1) + pictureBox1.Top;
                        pic2.Size = new Size(74, 74);
                        pic2.Load("Lu\\16.gif");
                        pic2.SizeMode = PictureBoxSizeMode.StretchImage;
                        Controls.Add(pic2);
                        pic2.BringToFront();
                    }
                } 
            }
            SoundPlayer simpleSound = new SoundPlayer("Lu\\ПКФТ.wav");
            simpleSound.Play();
            afte = false;
            await Task.Delay(1400);
            pic2.SendToBack();
            (pic2).Dispose();
            this.Controls.Remove(pic2);
            timer1.Stop();
            NewMethod1();
            if (!Главное_Меню)
            {
                pictureBox1.Top = 60;
                pictureBox1.Left = 0;
                pictureBox1.Load("Zero1.png"); 
            }
        }
        private async void Смерть_Вражины(int f, int ol, int I, int c)
        {
            gr.FillRectangle(prep5, 25 * c, 25 * I, 25, 25);
            pic4[I, c] = new PictureBox();
            pic4[I, c].Left = 25 * c+pictureBox1.Left;
            pic4[I, c].Top = 25 * I + pictureBox1.Top;
            pic4[I, c].Size = new Size(24, 24);
            pic4[I, c].Load("Lu\\16.gif");
            pic4[I, c].SizeMode = PictureBoxSizeMode.StretchImage;
            Controls.Add(pic4[I, c]);
            pic4[I, c].BringToFront();
            SoundPlayer simpleSound = new SoundPlayer("Lu\\ПКФТ.wav");
            simpleSound.Play();
            rio[I, c] = ' ';
            await Task.Delay(70);
            pic4[I, c].Load("Lu\\1.jpg");
            pic4[I, c].SendToBack();
            (pic4[I, c]).Dispose();
            Controls.Remove(pic4[I, c]);
        }

        int t = 0, g = 0;
        int[] per = new int[3];
        private char[,] rio = new char[100, 100];

        private void label5_Click(object sender, EventArgs e)
        {
            afte = true;
            Lev = 1;
            dio = 0;
            NewMethod2();
            NewMethod();
            Главное_Меню = false;
            to = 1;
        }

        private void NewMethod2()
        {
            label1.Enabled = true;
            label1.Visible = true;
            label2.Enabled = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Enabled = false;
            label4.Visible = false;
            label5.Enabled = false;
            label5.Visible = false;
            label6.Enabled = false;
            label6.Visible = false;
            label7.Enabled = false;
            label7.Visible = false;
        }
        bool Главное_Меню = false;
        private async void label1_Click(object sender, EventArgs e)
        {
            x = 0;
            afte = false;
            Главное_Меню = true;
            await Task.Delay(100);
            NewMethod1();
            label1.Enabled = false;
            label1.Visible = false;
            label2.Enabled = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Enabled = true;
            label4.Visible = true;
            label5.Enabled = true;
            label5.Visible = true;
            label6.Enabled = true;
            label6.Visible = true;
            label7.Enabled = true;
            label7.Visible = true;
            to = 0;
            pictureBox1.Top = 60;
            pictureBox1.Left = 0;
            pictureBox1.Load("Zero.png");
        }

        private void label4_Click(object sender, EventArgs e)
        {
            afte = true;
            using (var sr = new System.IO.StreamReader("Lu\\trip.txt"))
            {
                Lev = int.Parse(sr.ReadToEnd());
            }
            dio = 0;
            NewMethod2();
            NewMethod();
            Главное_Меню = false;
            to = 1;
        }


        int dio = 0;
        string duo = "";
        private void label6_Click(object sender, EventArgs e)
        {
            x = 0;
            dio = 1;
            openFileDialog1.Filter = "Текстовые файлы|*.txt";
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel) 
            { 
                dio = 0; 
                return; 
            }
            try
            {
                afte = true;
                duo = openFileDialog1.FileName;
                NewMethod1();
                NewMethod2();
                NewMethod();
                label1.BringToFront();
                Главное_Меню = false;
            }
            catch (Exception)
            {
                MessageBox.Show("Ошибка открытия");
            }
        }

        public void Rkfw(object sender, EventArgs e)
        {
            Close();
        }

        private void Crim(object sender, EventArgs e)
        {
            Image img = Image.FromFile("Lu\\кнопка(тёмная).png");
            ((Label)sender).Image = img;
            ((Label)sender).ForeColor = Color.Red;
        }

        private void NotCrim(object sender, EventArgs e)
        {
            Image img = Image.FromFile("Lu\\кнопка(светлая).png");
            ((Label)sender).Image = img;
            ((Label)sender).ForeColor = Color.Black;
        }


        private async void ert(object sender, MouseEventArgs e)
        {
            label2.Enabled = false;
            label2.Visible = false;
            label1.Enabled = false;
            label1.Visible = false;
            afte = false;
            uo = 0;
            NewMethod1();
            NewMethod();
            pictureBox1.Top = 60;
            pictureBox1.Left = 0;
            await Task.Delay(600);
            label1.Enabled = true;
            label1.Visible = true;
            label2.Enabled = true;
            label2.Visible = true;
        }
        int lion = 0;
        private void Pinokkio(object sender, KeyEventArgs e)
        {
            var paintBitmap = (Bitmap)pictureBox1.Image;
            switch (e.KeyCode.ToString())
            {
                case "Down":
                    lion = 0;
                    break;
                case "Up":
                    lion = 0;
                    break;
                case "Right":
                    lion = 0;
                    break;
                case "Left":
                    lion = 0;
                    break;
            }
        }

        private async void pio(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.N)
            {
                MessageBox.Show("Тест");
                e.Handled = true;
            }
            if (e.KeyCode == Keys.R & label2.Enabled == true)
            {
                label2.Enabled = false;
                label2.Visible = false;
                label1.Enabled = false;
                label1.Visible = false;
                afte = false;
                uo = 0;
                NewMethod1();
                NewMethod();
                pictureBox1.Top = 60; 
                pictureBox1.Left = 0;
                await Task.Delay(600);
                label1.Enabled = true;
                label1.Visible = true;
                label2.Enabled = true;
                label2.Visible = true;
            }
            if (to == 1)
            {
                switch (e.KeyCode.ToString()) 
                {
                    case "Down":
                        lion = 1;
                        break;
                    case "Up":
                        lion = 2;
                        break;
                    case "Right":
                        lion = 3;
                        break;
                    case "Left":
                        lion = 4;
                        break;
                    case "Escape":
                        x = 0;
                        afte = false;
                        Главное_Меню = true;
                        await Task.Delay(100);
                        NewMethod1();
                        label1.Enabled = false;
                        label1.Visible = false;
                        label2.Enabled = false;
                        label2.Visible = false;
                        label3.Visible = false;
                        label4.Enabled = true;
                        label4.Visible = true;
                        label5.Enabled = true;
                        label5.Visible = true;
                        label6.Enabled = true;
                        label6.Visible = true;
                        label7.Enabled = true;
                        label7.Visible = true;
                        to = 0;
                        pictureBox1.Top = 60; 
                        pictureBox1.Left = 0;
                        pictureBox1.Load("Zero.png");
                        break;
                }
            }

        }

        int uo = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {

            if (pic2 != null)
            { Controls.Remove(pic2); }
        }

        private async void mant()
        {
            if (to == 1)
            {
                while (afte)
                {
                    Point poi;
                    bool NextLvl = false;
                    while (lion == 1 & to == 1)//вниз
                    {
                        vbok = 10;
                        if (rio[g + 1, t] == ' ' || rio[g + 1, t] == '0')
                        {
                            rio[g, t] = ' ';
                            rio[g+1, t] = '@';
                            gr.FillRectangle(prep5, per[1], per[2], 24, 24); 
                            per[2] = per[2] + 25;
                            for (int j = 1; j < 7; j++)
                            {
                                poi = new Point(t * 25, g * 25 + j * 4);
                                gr.FillRectangle(prep5, 25 * t, 25 * g + j * 4, 25, 25);
                                gr.DrawImage(PlayerModels[1], poi);
                                if (per[2] > Screen.PrimaryScreen.Bounds.Height / 100 * 100 - 300) pictureBox1.Top = pictureBox1.Top - 4;
                                await Task.Delay(1);
                                if (j < 7) gr.FillRectangle(prep5, 25 * t, 25 * g + (j - 1) * 4, 25, 25);
                            }
                            if (per[2] > Screen.PrimaryScreen.Bounds.Height / 100 * 100 - 300) pictureBox1.Top = pictureBox1.Top - 1;
                            g++;
                            gr.FillRectangle(prep5, 25 * t, 25 * g, 25, 25);
                            poi = new Point(t * 25, g * 25);
                            gr.DrawImage(PlayerModels[1], poi);
                        }
                        else if (rio[g + 1, t] == '.')
                        {
                            vbok = -3;
                            rio[g, t] = ' ';
                            rio[g + 1, t] = '@';
                            gr.FillRectangle(prep5, per[1], per[2], 24, 24); per[2] = per[2] + 25;
                            for (int j = 1; j < 7; j++)
                            {
                                poi = new Point(t * 25, g * 25 + j * 4);
                                gr.FillRectangle(prep5, 25 * t, 25 * g + j * 4, 25, 25);
                                gr.DrawImage(PlayerModels[1], poi);
                                await Task.Delay(1);
                                if (j < 7) gr.FillRectangle(prep5, 25 * t, 25 * g + (j - 1) * 4, 25, 25);
                            }
                            g++;
                            gr.FillRectangle(prep5, 25 * t, 25 * g, 25, 25);
                            poi = new Point(t * 25, g * 25);
                            gr.DrawImage(PlayerModels[1], poi);
                            uo++;
                            label3.Text = "Собрано: " + Convert.ToString(uo);
                        }
                        else if (rio[g + 1, t] == 'Q' & uo == x)
                        {
                            NextLvl = true;
                        }
                        await Task.Delay(1);
                    }
                    while (lion == 2 & to == 1)//вверх
                    {
                        vbok = 10;
                        if (rio[g - 1, t] == ' ' || rio[g - 1, t] == '0')
                        {
                            rio[g, t] = ' ';
                            rio[g - 1, t] = '@';
                            gr.FillRectangle(prep5, per[1], per[2], 24, 24); 
                            per[2] = per[2] - 25;
                            for (int j = 1; j < 7; j++)
                            {
                                poi = new Point(t * 25, g * 25 - j * 4);
                                gr.FillRectangle(prep5, 25 * t, 25 * g - j * 4, 25, 25);
                                gr.DrawImage(PlayerModels[2], poi);
                                if (per[2] >= Screen.PrimaryScreen.Bounds.Height / 100 * 100 - 300) pictureBox1.Top = pictureBox1.Top + 4;
                                await Task.Delay(1);
                                if (j < 7) gr.FillRectangle(prep5, 25 * t, 25 * g - (j - 1) * 4, 25, 25);
                            }
                            if (per[2] >= Screen.PrimaryScreen.Bounds.Height / 100 * 100 - 300) pictureBox1.Top = pictureBox1.Top + 1;
                            g--;
                            gr.FillRectangle(prep5, 25 * t, 25 * g, 25, 25);
                            poi = new Point(t * 25, g * 25);
                            gr.DrawImage(PlayerModels[2], poi);
                        }
                        else if (rio[g - 1, t] == '.')
                        {
                            vbok = 3;
                            rio[g, t] = ' ';
                            rio[g - 1, t] = '@';
                            gr.FillRectangle(prep5, per[1], per[2], 24, 24); 
                            per[2] = per[2] - 25;
                            for (int j = 1; j < 7; j++)
                            {
                                poi = new Point(t * 25, g * 25 - j * 4);
                                gr.FillRectangle(prep5, 25 * t, 25 * g - j * 4, 25, 25);
                                gr.DrawImage(PlayerModels[2], poi);
                                await Task.Delay(1);
                                if (j < 7) gr.FillRectangle(prep5, 25 * t, 25 * g - (j - 1) * 4, 25, 25);
                            }
                            g--;
                            gr.FillRectangle(prep5, 25 * t, 25 * g, 25, 25);
                            poi = new Point(t * 25, g * 25);
                            gr.DrawImage(PlayerModels[2], poi);
                            uo++;
                            label3.Text = "Собрано: " + Convert.ToString(uo);
                        }
                        else if (rio[g - 1, t] == 'Q' & uo == x)
                        {
                            NextLvl = true;
                        }
                        await Task.Delay(1);
                    }


                    while (lion == 3 & to == 1) //вправо
                    {
                        if (rio[g, t + 1] == '*')
                        {
                            vbok = -1;
                        }
                        if ((rio[g, t + 1] == ' ' || rio[g, t + 1] == '0') & vbok != 0)
                        {
                            rio[g, t] = ' ';
                            rio[g, t+1] = '@';
                            gr.FillRectangle(prep5, per[1], per[2], 24, 24); 
                            per[1] = per[1] + 25;
                            for (int j = 1; j < 7; j++)
                            {
                                poi = new Point(t * 25 + j * 4, g * 25);
                                gr.FillRectangle(prep5, 25 * t + j * 4, 25 * g, 25, 25);
                                gr.DrawImage(PlayerModels[3], poi);
                                if (per[1] > Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left - 4;
                                await Task.Delay(1);
                                if (j < 7) gr.FillRectangle(prep5, 25 * t + (j - 1) * 4, 25 * g, 25, 25);
                            }
                            t++;
                            if (per[1] > Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left - 1;
                            gr.FillRectangle(prep5, 25 * t, 25 * g, 25, 25);
                            poi = new Point(t * 25, g * 25);
                            gr.DrawImage(PlayerModels[3], poi);
                        }
                        else if (rio[g, t + 1] == '.')
                        {
                            vbok = 2;
                            rio[g, t] = ' ';
                            rio[g, t+1] = '@';
                            gr.FillRectangle(prep5, per[1], per[2], 24, 24); 
                            per[1] = per[1] + 25;
                            for (int j = 1; j < 7; j++)
                            {
                                poi = new Point(t * 25 + j * 4, g * 25);
                                gr.FillRectangle(prep5, 25 * t + j * 4, 25 * g, 25, 25);
                                gr.DrawImage(PlayerModels[3], poi);
                                if(per[1]> Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left - 4;
                                await Task.Delay(1);
                                if (j < 7) gr.FillRectangle(prep5, 25 * t + (j - 1) * 4, 25 * g, 25, 25);
                            }
                            t++;
                            if (per[1] > Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left - 1;
                            gr.FillRectangle(prep5, 25 * t, 25 * g, 25, 25);
                            poi = new Point(t * 25, g * 25);
                            gr.DrawImage(PlayerModels[3], poi);
                            uo++;
                            label3.Text = "Собрано: " + Convert.ToString(uo);
                        }
                        else if (rio[g, t + 1] == 'Q' & uo == x)
                        {
                            NextLvl = true;
                        }
                        await Task.Delay(1);
                    }

                    while (lion == 4 & to == 1)//влево
                    {

                        if (rio[g, t - 1] == '*')
                        {
                            vbok = 1;
                        }
                        if ((rio[g, t - 1] == ' ' || rio[g, t - 1] == '0') & vbok != 0)
                        {
                            rio[g, t] = ' ';
                            rio[g, t - 1] = '@';
                            gr.FillRectangle(prep5, per[1], per[2], 24, 24); 
                            per[1] = per[1] - 25;
                            for (int j = 1; j < 7; j++)
                            {
                                poi = new Point(t * 25 - j * 4, g * 25);
                                gr.FillRectangle(prep5, 25 * t - j * 4, 25 * g, 25, 25);
                                gr.DrawImage(PlayerModels[4], poi);
                                if (per[1] >= Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left + 4;
                                await Task.Delay(1);
                                if (j < 7) gr.FillRectangle(prep5, 25 * t - (j - 1) * 4, 25 * g, 25, 25);
                            }
                            if (per[1] >= Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left + 1;
                            t--;
                            gr.FillRectangle(prep5, 25 * t, 25 * g, 25, 25);
                            poi = new Point(t * 25, g * 25);
                            gr.DrawImage(PlayerModels[4], poi);
                        }
                        else if (rio[g, t - 1] == '.')
                        {
                            vbok = -2;
                            rio[g, t] = ' ';
                            rio[g, t - 1] = '@';
                            gr.FillRectangle(prep5, per[1], per[2], 24, 24); 
                            per[1] = per[1] - 25;
                            for (int j = 1; j < 7; j++)
                            {
                                poi = new Point(t * 25 - j * 4, g * 25);
                                gr.FillRectangle(prep5, 25 * t - j * 4, 25 * g, 25, 25);
                                gr.DrawImage(PlayerModels[4], poi);
                                if (per[1] >= Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left + 4;
                                await Task.Delay(1);
                                if (j < 7) gr.FillRectangle(prep5, 25 * t - (j - 1) * 4, 25 * g, 25, 25);
                            }
                            if (per[1] >= Screen.PrimaryScreen.Bounds.Width / 100 * 100 - 300) pictureBox1.Left = pictureBox1.Left + 1;
                            t--;
                            gr.FillRectangle(prep5, 25 * t, 25 * g, 25, 25);
                            poi = new Point(t * 25, g * 25);
                            gr.DrawImageUnscaled(PlayerModels[4], poi);
                            uo++;
                            label3.Text = "Собрано: " + Convert.ToString(uo);
                        }
                        else if (rio[g, t - 1] == 'Q' & uo == x)
                        {
                            NextLvl = true;
                        }
                        await Task.Delay(1);
                    }
                    if (NextLvl)
                    {
                        if (dio == 0)
                        {
                            to = 9;
                            Lev++;
                            afte = false;
                            using (StreamWriter sw = new StreamWriter("Lu\\trip.txt"))
                            { sw.Write(Convert.ToString(Lev)); }
                            if (Lev < 10) NewMethod();
                            else { NewMethod1(); label2.Enabled = false; label2.Visible = false; await Task.Delay(25); pictureBox1.Top = 60; pictureBox1.Left = 0; pictureBox1.Load("Zero3.png");}
                        }
                        else { NewMethod1(); await Task.Delay(25); pictureBox1.Top = 60; pictureBox1.Left = 0; pictureBox1.Load("Zero2.png"); }
                    }
                    await Task.Delay(1);
                }
            }
        }
    }
}
